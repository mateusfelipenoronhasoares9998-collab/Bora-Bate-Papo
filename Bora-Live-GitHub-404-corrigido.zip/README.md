# Bora Live — Loja + Contas

Esta versão mantém a loja e adiciona uma camada de conta para vincular compras ao usuário.

## Conta
- Criar conta com e-mail e senha.
- Entrar com a conta criada no mesmo navegador.
- Perfil persistente neste navegador.
- Nome do perfil fica bloqueado após a criação/vinculação.
- Login Google aproveita o login Google já preparado no Bora Live e salva o nome/e-mail retornados.
- Compras enviam `userId`, e-mail e nome ao endpoint de pagamento para que o pedido possa ser vinculado à conta.

## Importante sobre produção
Esta versão é um protótipo estático: a conta local usa armazenamento do navegador. Para contas realmente seguras e recuperáveis em qualquer aparelho, conecte a autenticação do Base44/Supabase/Firebase ou outro backend com banco de dados. Senhas não devem ser armazenadas em localStorage em uma versão de produção.

O pagamento também continua preparado para funcionar com um backend: nenhum segredo Pix deve ser colocado no HTML. O servidor deve criar a cobrança e confirmar o pagamento por webhook antes de liberar o item.

## Google
O login Google do projeto depende de um Client ID configurado no projeto Google Cloud. Não coloque client secret no frontend.

## Animações Halloween — modo ultra-fluido
- As animações de entrada, bruxa, partículas e elementos de Halloween foram preservadas.
- O modo automático não desliga mais todas as animações em aparelhos fracos.
- Um monitor leve detecta quedas persistentes de frame e reduz apenas filtros/glows pesados, mantendo o movimento.
- A otimização usa `requestAnimationFrame` para acompanhar o ciclo de pintura do navegador.


## GitHub Pages

Esta versão normaliza os links internos para funcionar mesmo quando a URL do projeto é aberta sem a barra final. A Loja também não tenta chamar `api/...` no GitHub Pages, porque o Pages hospeda arquivos estáticos; o pagamento real exige um backend separado.
