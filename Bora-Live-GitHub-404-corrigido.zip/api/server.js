// Bora Live — payment backend template
// IMPORTANT: never put MERCADO_PAGO_ACCESS_TOKEN or webhook secrets in frontend code.
// Configure these values only on the server/environment of the person responsible for payments.

const express = require('express');
const crypto = require('crypto');
const { MercadoPagoConfig, Payment } = require('mercadopago');
require('dotenv').config();

const app = express();
app.use(express.json({ limit: '100kb' }));

const PORT = process.env.PORT || 3000;
const ACCESS_TOKEN = process.env.MERCADO_PAGO_ACCESS_TOKEN;
const WEBHOOK_SECRET = process.env.MERCADO_PAGO_WEBHOOK_SECRET || '';

// Demo-only in-memory order store. For production, replace with a real database.
const orders = new Map();

function money(v) {
  const n = Number(v);
  if (!Number.isFinite(n) || n <= 0 || n > 1000) throw new Error('Invalid amount');
  return Math.round(n * 100) / 100;
}

function id() { return crypto.randomUUID(); }

app.post('/api/create-payment', async (req, res) => {
  try {
    if (!ACCESS_TOKEN) return res.status(503).json({ error: 'PAYMENTS_NOT_CONFIGURED' });

    const amount = money(req.body.amount);
    const item = String(req.body.item || '').slice(0, 120);
    const type = req.body.type === 'box' ? 'box' : 'item';
    if (!item) return res.status(400).json({ error: 'INVALID_ITEM' });

    const orderId = id();
    const client = new MercadoPagoConfig({ accessToken: ACCESS_TOKEN });
    const payment = new Payment(client);

    const result = await payment.create({
      body: {
        transaction_amount: amount,
        description: `Bora Live - ${item}`,
        payment_method_id: 'pix',
        external_reference: orderId,
        notification_url: process.env.PUBLIC_WEBHOOK_URL,
        payer: { email: req.body.email || 'checkout@boralive.local' }
      },
      requestOptions: { idempotencyKey: orderId }
    });

    const tx = result.point_of_interaction?.transaction_data;
    orders.set(orderId, { orderId, item, type, amount, paymentId: String(result.id), status: result.status || 'pending', createdAt: Date.now() });

    res.json({
      orderId,
      status: result.status,
      qrCode: tx?.qr_code || null,
      qrCodeBase64: tx?.qr_code_base64 || null,
      ticketUrl: tx?.ticket_url || null
    });
  } catch (err) {
    console.error('create-payment:', err.message);
    res.status(500).json({ error: 'PAYMENT_CREATE_FAILED' });
  }
});

app.get('/api/payment-status/:orderId', async (req, res) => {
  const order = orders.get(req.params.orderId);
  if (!order) return res.status(404).json({ error: 'ORDER_NOT_FOUND' });

  // For production, query the provider or use the webhook-updated status from a database.
  res.json({ orderId: order.orderId, status: order.status === 'approved' ? 'approved' : 'pending' });
});

function verifyWebhook(req) {
  // Keep this function server-side. Implement the provider's current x-signature validation
  // before trusting webhook data. Never accept a browser request as payment proof.
  return !WEBHOOK_SECRET || Boolean(req.headers['x-signature']);
}

app.post('/api/webhooks/mercadopago', async (req, res) => {
  try {
    if (!verifyWebhook(req)) return res.status(401).send('invalid signature');
    // Fetch the payment by ID from Mercado Pago here, verify it is approved,
    // match external_reference to an order, and only then mark the order approved.
    const paymentId = req.body?.data?.id || req.body?.id;
    if (!paymentId) return res.sendStatus(200);

    // TODO production: retrieve payment from Mercado Pago using paymentId and verify:
    // status === 'approved', transaction_amount matches the order, and external_reference matches.
    // Then persist the approved state atomically to prevent duplicate item delivery.
    res.sendStatus(200);
  } catch (err) {
    console.error('webhook:', err.message);
    res.sendStatus(500);
  }
});

app.get('/health', (_req, res) => res.json({ ok: true }));
app.listen(PORT, () => console.log(`Bora Live payment server listening on :${PORT}`));
