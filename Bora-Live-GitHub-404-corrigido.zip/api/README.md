# Pagamentos do Bora Live

Esta pasta é o backend do checkout Pix. A chave/credencial privada nunca deve ser colocada no HTML ou JavaScript público.

## Fluxo
1. A loja pede ao backend a criação de uma cobrança.
2. O backend cria o pagamento Pix no provedor.
3. A loja recebe apenas os dados de pagamento necessários ao comprador (QR/Pix Copia e Cola).
4. O provedor envia um webhook ao backend quando o pagamento muda de estado.
5. O backend valida o pagamento e só então libera o item/caixa.

## Importante
O arquivo `server.js` é um esqueleto seguro para integração e ainda exige configuração de produção, validação completa da assinatura do webhook e banco de dados persistente antes de receber dinheiro de verdade.

Não coloque credenciais reais em `index.html`, GitHub Pages ou qualquer arquivo público.
